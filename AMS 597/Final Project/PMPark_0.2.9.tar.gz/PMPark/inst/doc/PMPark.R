## ----partially matched sample-------------------------------------------------
set.seed(123)
x <- rnorm(20)
y <- rnorm(20) + 2
x[c(1,5,8)] <- NA
y[c(2,13,19,20)] <- NA
data.frame(x,y)

## ----n1, n2, and n3-----------------------------------------------------------
n1 <- length(which(!is.na(x)&!is.na(y)))
n2 <- length(which(!is.na(x)&is.na(y)))
n3 <- length(which(is.na(x)&!is.na(y)))
data.frame(n1,n2,n3)

## ----calling package----------------------------------------------------------
library(PMPark)

## ----data representation------------------------------------------------------
data.frame(x,y)

## ----two sided testing--------------------------------------------------------
weighted.z.test(x,y)

## ----one sided testing: less--------------------------------------------------
weighted.z.test(x,y,alternative="less")

## ----one sided testing: "greater"---------------------------------------------
weighted.z.test(x,y,alternative="greater")

